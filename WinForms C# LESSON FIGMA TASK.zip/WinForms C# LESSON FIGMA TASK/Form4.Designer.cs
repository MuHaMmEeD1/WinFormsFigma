﻿namespace WinForms_C__LESSON_FIGMA_TASK
{
    partial class Form4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form4));
            label3 = new Label();
            SubmitButton = new Button();
            codeTextBox1 = new TextBox();
            label1 = new Label();
            pictureBox1 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.Font = new Font("Segoe Fluent Icons", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(83, 664);
            label3.Name = "label3";
            label3.Size = new Size(227, 17);
            label3.TabIndex = 13;
            label3.Text = "a product by Product Design LLC";
            // 
            // SubmitButton
            // 
            SubmitButton.BackColor = Color.FromArgb(32, 60, 133);
            SubmitButton.FlatStyle = FlatStyle.Flat;
            SubmitButton.Font = new Font("Sans Serif Collection", 6.1F, FontStyle.Bold, GraphicsUnit.Point);
            SubmitButton.ForeColor = Color.FromArgb(240, 240, 240);
            SubmitButton.Location = new Point(57, 349);
            SubmitButton.Name = "SubmitButton";
            SubmitButton.Size = new Size(261, 54);
            SubmitButton.TabIndex = 12;
            SubmitButton.Text = "Submit";
            SubmitButton.UseVisualStyleBackColor = true;
            SubmitButton.Click += SubmitButton_Click;
            // 
            // codeTextBox1
            // 
            codeTextBox1.BorderStyle = BorderStyle.None;
            codeTextBox1.Font = new Font("Sans Serif Collection", 9.8F, FontStyle.Bold, GraphicsUnit.Point);
            codeTextBox1.ForeColor = Color.Silver;
            codeTextBox1.Location = new Point(70, 271);
            codeTextBox1.Name = "codeTextBox1";
            codeTextBox1.Size = new Size(238, 41);
            codeTextBox1.TabIndex = 10;
            codeTextBox1.Text = "code";
            codeTextBox1.MouseClick += codeTextBox1_MouseClick;
            // 
            // label1
            // 
            label1.BackColor = SystemColors.Window;
            label1.Location = new Point(58, 261);
            label1.Name = "label1";
            label1.Size = new Size(260, 60);
            label1.TabIndex = 11;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-2, 40);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(378, 197);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // Form4
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(375, 700);
            Controls.Add(label3);
            Controls.Add(SubmitButton);
            Controls.Add(codeTextBox1);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form4";
            StartPosition = FormStartPosition.CenterScreen;
            FormClosed += FormClosed_;
            Load += Form4_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private Button SubmitButton;
        private TextBox codeTextBox1;
        private Label label1;
        private PictureBox pictureBox1;
    }
}