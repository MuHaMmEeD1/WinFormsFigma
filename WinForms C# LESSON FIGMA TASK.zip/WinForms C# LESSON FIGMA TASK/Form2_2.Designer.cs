﻿namespace WinForms_C__LESSON_FIGMA_TASK
{
    partial class Form2_2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2_2));
            label3 = new Label();
            ConfirmButton = new Button();
            confirmPassTextBox1 = new TextBox();
            label2 = new Label();
            PasswordTextBox1 = new TextBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.Font = new Font("Segoe Fluent Icons", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Image = (Image)resources.GetObject("label3.Image");
            label3.Location = new Point(83, 664);
            label3.Name = "label3";
            label3.Size = new Size(227, 17);
            label3.TabIndex = 23;
            label3.Text = "a product by Product Design LLC";
            // 
            // ConfirmButton
            // 
            ConfirmButton.BackColor = Color.FromArgb(32, 60, 133);
            ConfirmButton.FlatStyle = FlatStyle.Flat;
            ConfirmButton.Font = new Font("Sans Serif Collection", 6.1F, FontStyle.Bold, GraphicsUnit.Point);
            ConfirmButton.ForeColor = Color.FromArgb(240, 240, 240);
            ConfirmButton.Location = new Point(58, 426);
            ConfirmButton.Name = "ConfirmButton";
            ConfirmButton.Size = new Size(261, 54);
            ConfirmButton.TabIndex = 22;
            ConfirmButton.Text = "Confirm";
            ConfirmButton.UseVisualStyleBackColor = true;
            ConfirmButton.Click += ConfirmButton_Click;
            // 
            // confirmPassTextBox1
            // 
            confirmPassTextBox1.BorderStyle = BorderStyle.None;
            confirmPassTextBox1.Font = new Font("Sans Serif Collection", 9.8F, FontStyle.Bold, GraphicsUnit.Point);
            confirmPassTextBox1.ForeColor = Color.Silver;
            confirmPassTextBox1.Location = new Point(70, 348);
            confirmPassTextBox1.Name = "confirmPassTextBox1";
            confirmPassTextBox1.Size = new Size(238, 41);
            confirmPassTextBox1.TabIndex = 20;
            confirmPassTextBox1.Text = "confirm pass";
            confirmPassTextBox1.MouseClick += confirmPassTextBox1_MouseClick;
            // 
            // label2
            // 
            label2.BackColor = SystemColors.Window;
            label2.Location = new Point(58, 338);
            label2.Name = "label2";
            label2.Size = new Size(260, 60);
            label2.TabIndex = 21;
            // 
            // PasswordTextBox1
            // 
            PasswordTextBox1.BorderStyle = BorderStyle.None;
            PasswordTextBox1.Font = new Font("Sans Serif Collection", 9.8F, FontStyle.Bold, GraphicsUnit.Point);
            PasswordTextBox1.ForeColor = Color.Silver;
            PasswordTextBox1.Location = new Point(70, 271);
            PasswordTextBox1.Name = "PasswordTextBox1";
            PasswordTextBox1.Size = new Size(238, 41);
            PasswordTextBox1.TabIndex = 18;
            PasswordTextBox1.Text = "password";
            PasswordTextBox1.MouseClick += PasswordTextBox1_MouseClick;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-2, 40);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(378, 197);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 17;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.BackColor = SystemColors.Window;
            label1.Location = new Point(58, 261);
            label1.Name = "label1";
            label1.Size = new Size(260, 60);
            label1.TabIndex = 19;
            // 
            // Form2_2
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(375, 700);
            Controls.Add(label3);
            Controls.Add(ConfirmButton);
            Controls.Add(confirmPassTextBox1);
            Controls.Add(label2);
            Controls.Add(PasswordTextBox1);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form2_2";
            StartPosition = FormStartPosition.CenterScreen;
            FormClosed += FormClosed_;
            Load += Form2_2_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private Button ConfirmButton;
        private TextBox confirmPassTextBox1;
        private Label label2;
        private TextBox PasswordTextBox1;
        private PictureBox pictureBox1;
        private Label label1;
    }
}