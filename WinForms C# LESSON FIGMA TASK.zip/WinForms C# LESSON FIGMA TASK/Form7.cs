﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms_C__LESSON_FIGMA_TASK
{
    public partial class Form7 : Form
    {



        Form form2; Form form;

        int index;

        bool goz = false;

        public Form7(Form form2, Form form, int index)
        {
            InitializeComponent();
            this.form2 = form2;
            this.form = form;
            this.index = index;
        }

        private void Form7_Load(object sender, EventArgs e)
        {

            List<Person> persons = new List<Person>();

            persons = JsonSerializer.Deserialize<List<Person>>(File.ReadAllText("../../../persons.json"));

            textBox1.Text = persons[index].Fastname;
            textBox2.Text = persons[index].Lastname;
            textBox3.Text = persons[index].Password;
            textBox4.Text = persons[index].Email;



        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            GraphicsPath path = new GraphicsPath();
            int radius = 5;
            Rectangle bounds = new Rectangle(0, 0, l1.Width - 2, l1.Height - 2);

            path.AddArc(bounds.Left, bounds.Top, radius, radius, 180, 90);
            path.AddArc(bounds.Right - radius, bounds.Top, radius, radius, 270, 90);
            path.AddArc(bounds.Right - radius, bounds.Bottom - radius, radius, radius, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - radius, radius, radius, 90, 90);
            path.CloseAllFigures();

            l1.Region = new Region(path);



            GraphicsPath path2 = new GraphicsPath();
            int radius2 = 5;
            Rectangle bounds2 = new Rectangle(0, 0, l2.Width - 2, l2.Height - 2);

            path2.AddArc(bounds2.Left, bounds2.Top, radius2, radius2, 180, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Top, radius2, radius2, 270, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Bottom - radius2, radius2, radius2, 0, 90);
            path2.AddArc(bounds2.Left, bounds2.Bottom - radius2, radius2, radius2, 90, 90);
            path2.CloseAllFigures();

            l2.Region = new Region(path2);


            GraphicsPath path3 = new GraphicsPath();
            int radius3 = 5;
            Rectangle bounds3 = new Rectangle(0, 0, l3.Width - 2, l3.Height - 2);

            path3.AddArc(bounds3.Left, bounds3.Top, radius3, radius3, 180, 90);
            path3.AddArc(bounds3.Right - radius3, bounds3.Top, radius3, radius3, 270, 90);
            path3.AddArc(bounds3.Right - radius3, bounds3.Bottom - radius3, radius3, radius3, 0, 90);
            path3.AddArc(bounds3.Left, bounds3.Bottom - radius3, radius3, radius3, 90, 90);
            path3.CloseAllFigures();

            l3.Region = new Region(path3);


            GraphicsPath path4 = new GraphicsPath();
            int radius4 = 5;
            Rectangle bounds4 = new Rectangle(0, 0, l4.Width - 2, l4.Height - 2);

            path4.AddArc(bounds4.Left, bounds4.Top, radius4, radius4, 180, 90);
            path4.AddArc(bounds4.Right - radius4, bounds4.Top, radius4, radius4, 270, 90);
            path4.AddArc(bounds4.Right - radius4, bounds4.Bottom - radius4, radius4, radius4, 0, 90);
            path4.AddArc(bounds4.Left, bounds4.Bottom - radius4, radius4, radius4, 90, 90);
            path4.CloseAllFigures();

            l4.Region = new Region(path4);



            GraphicsPath path5 = new GraphicsPath();
            int radius5 = 10;
            Rectangle bounds5 = new Rectangle(2, 2, button1.Width - 4, button1.Height - 4);

            path5.AddArc(bounds5.Left, bounds5.Top, radius5, radius5, 180, 90);
            path5.AddArc(bounds5.Right - radius5, bounds5.Top, radius5, radius5, 270, 90);
            path5.AddArc(bounds5.Right - radius5, bounds5.Bottom - radius5, radius5, radius5, 0, 90);
            path5.AddArc(bounds5.Left, bounds5.Bottom - radius5, radius5, radius5, 90, 90);
            path5.CloseAllFigures();

            button1.Region = new Region(path5);



            GraphicsPath path6 = new GraphicsPath();
            int radius6 = 10;
            Rectangle bounds6 = new Rectangle(2, 2, button2.Width - 4, button2.Height - 4);

            path6.AddArc(bounds6.Left, bounds6.Top, radius6, radius6, 180, 90);
            path6.AddArc(bounds6.Right - radius6, bounds6.Top, radius6, radius6, 270, 90);
            path6.AddArc(bounds6.Right - radius6, bounds6.Bottom - radius6, radius6, radius6, 0, 90);
            path6.AddArc(bounds6.Left, bounds6.Bottom - radius6, radius6, radius6, 90, 90);
            path6.CloseAllFigures();

            button2.Region = new Region(path6);



            GraphicsPath path7 = new GraphicsPath();
            int radius7 = 10;
            Rectangle bounds7 = new Rectangle(2, 2, button3.Width - 4, button3.Height - 4);

            path7.AddArc(bounds7.Left, bounds7.Top, radius7, radius7, 180, 90);
            path7.AddArc(bounds7.Right - radius7, bounds7.Top, radius7, radius7, 270, 90);
            path7.AddArc(bounds7.Right - radius7, bounds7.Bottom - radius7, radius7, radius7, 0, 90);
            path7.AddArc(bounds7.Left, bounds7.Bottom - radius7, radius7, radius7, 90, 90);
            path7.CloseAllFigures();

            button3.Region = new Region(path7);



            GraphicsPath path8 = new GraphicsPath();
            int radius8 = 10;
            Rectangle bounds8 = new Rectangle(2, 2, button4.Width - 4, button4.Height - 4);

            path8.AddArc(bounds8.Left, bounds8.Top, radius8, radius8, 180, 90);
            path8.AddArc(bounds8.Right - radius8, bounds8.Top, radius8, radius8, 270, 90);
            path8.AddArc(bounds8.Right - radius8, bounds8.Bottom - radius8, radius8, radius8, 0, 90);
            path8.AddArc(bounds8.Left, bounds8.Bottom - radius8, radius8, radius8, 90, 90);
            path8.CloseAllFigures();

            button4.Region = new Region(path8);













        }



        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
        private void FormClosed_(object? sender, EventArgs e)
        {

            form.Close();
            form2.Close();

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

            if (goz)
            {
                pictureBox3.Image = Properties.Resources.aciqGoz1;
                textBox3.PasswordChar = '\0';
            }
            else
            {
                pictureBox3.Image = Properties.Resources.bagliGoz1;
                textBox3.PasswordChar = '*';
            }
            goz = !goz;
        }

        private void label2_Click(object sender, EventArgs e)
        {

            openFileDialog1.Filter = "Foto|*.png";

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {

  
                Image selectedImage = new System.Drawing.Bitmap(openFileDialog1.FileName);

                pictureBox2.Image = selectedImage;



            }
        }
    }
}
