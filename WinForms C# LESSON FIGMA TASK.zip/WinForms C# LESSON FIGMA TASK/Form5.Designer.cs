﻿namespace WinForms_C__LESSON_FIGMA_TASK
{
    partial class Form5
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form5));
            label3 = new Label();
            updatePasswordButton = new Button();
            confirmPassTextBox1 = new TextBox();
            label2 = new Label();
            newPassTextBox1 = new TextBox();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.Font = new Font("Segoe Fluent Icons", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Image = (Image)resources.GetObject("label3.Image");
            label3.Location = new Point(83, 664);
            label3.Name = "label3";
            label3.Size = new Size(227, 17);
            label3.TabIndex = 16;
            label3.Text = "a product by Product Design LLC";
            // 
            // updatePasswordButton
            // 
            updatePasswordButton.BackColor = Color.FromArgb(32, 60, 133);
            updatePasswordButton.FlatStyle = FlatStyle.Flat;
            updatePasswordButton.Font = new Font("Sans Serif Collection", 6.1F, FontStyle.Bold, GraphicsUnit.Point);
            updatePasswordButton.ForeColor = Color.FromArgb(240, 240, 240);
            updatePasswordButton.Location = new Point(58, 426);
            updatePasswordButton.Name = "updatePasswordButton";
            updatePasswordButton.Size = new Size(261, 54);
            updatePasswordButton.TabIndex = 15;
            updatePasswordButton.Text = "Update password";
            updatePasswordButton.UseVisualStyleBackColor = true;
            updatePasswordButton.Click += updatePasswordButton_Click;
            // 
            // confirmPassTextBox1
            // 
            confirmPassTextBox1.BorderStyle = BorderStyle.None;
            confirmPassTextBox1.Font = new Font("Sans Serif Collection", 9.8F, FontStyle.Bold, GraphicsUnit.Point);
            confirmPassTextBox1.ForeColor = Color.Silver;
            confirmPassTextBox1.Location = new Point(70, 348);
            confirmPassTextBox1.Name = "confirmPassTextBox1";
            confirmPassTextBox1.Size = new Size(238, 41);
            confirmPassTextBox1.TabIndex = 13;
            confirmPassTextBox1.Text = "confirm pass";
            confirmPassTextBox1.MouseClick += confirmPassTextBox1_MouseClick;
            // 
            // label2
            // 
            label2.BackColor = SystemColors.Window;
            label2.Location = new Point(58, 338);
            label2.Name = "label2";
            label2.Size = new Size(260, 60);
            label2.TabIndex = 14;
            // 
            // newPassTextBox1
            // 
            newPassTextBox1.BorderStyle = BorderStyle.None;
            newPassTextBox1.Font = new Font("Sans Serif Collection", 9.8F, FontStyle.Bold, GraphicsUnit.Point);
            newPassTextBox1.ForeColor = Color.Silver;
            newPassTextBox1.Location = new Point(70, 271);
            newPassTextBox1.Name = "newPassTextBox1";
            newPassTextBox1.Size = new Size(238, 41);
            newPassTextBox1.TabIndex = 11;
            newPassTextBox1.Text = "new pass";
            newPassTextBox1.MouseClick += newPassTextBox1_MouseClick;
            newPassTextBox1.TextChanged += newPassTextBox1_TextChanged;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-2, 40);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(378, 197);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.BackColor = SystemColors.Window;
            label1.Location = new Point(58, 261);
            label1.Name = "label1";
            label1.Size = new Size(260, 60);
            label1.TabIndex = 12;
            label1.Click += label1_Click;
            // 
            // Form5
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(375, 700);
            Controls.Add(label3);
            Controls.Add(updatePasswordButton);
            Controls.Add(confirmPassTextBox1);
            Controls.Add(label2);
            Controls.Add(newPassTextBox1);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form5";
            StartPosition = FormStartPosition.CenterScreen;
            FormClosed += FormClosed_;
            Load += Form5_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label3;
        private Button updatePasswordButton;
        private TextBox confirmPassTextBox1;
        private Label label2;
        private TextBox newPassTextBox1;
        private PictureBox pictureBox1;
        private Label label1;
    }
}