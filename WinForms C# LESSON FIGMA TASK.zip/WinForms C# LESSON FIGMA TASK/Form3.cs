﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms_C__LESSON_FIGMA_TASK
{
    public partial class Form3 : Form
    {
        public Form Form;

        bool y1 = true;

        public Form Base;

        int randomSay = Random.Shared.Next(100000, 999999);
        public Form3(Form @base)
        {
            InitializeComponent();
            Base = @base;
        }

        

        private void Form3_Load(object sender, EventArgs e)
        {

        }


        private void FormClosed_(object? sender, EventArgs e)
        {

            Base.Dispose();

        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            GraphicsPath path = new GraphicsPath();
            int radius = 5;
            Rectangle bounds = new Rectangle(0, 0, label1.Width - 2, label1.Height - 2);

            path.AddArc(bounds.Left, bounds.Top, radius, radius, 180, 90);
            path.AddArc(bounds.Right - radius, bounds.Top, radius, radius, 270, 90);
            path.AddArc(bounds.Right - radius, bounds.Bottom - radius, radius, radius, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - radius, radius, radius, 90, 90);
            path.CloseAllFigures();

            label1.Region = new Region(path);



            GraphicsPath path2 = new GraphicsPath();
            int radius2 = 15;
            Rectangle bounds2 = new Rectangle(0, 0, SubmitButton.Width - 2, SubmitButton.Height - 2);

            path2.AddArc(bounds2.Left, bounds2.Top, radius2, radius2, 180, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Top, radius2, radius2, 270, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Bottom - radius2, radius2, radius2, 0, 90);
            path2.AddArc(bounds2.Left, bounds2.Bottom - radius2, radius2, radius2, 90, 90);
            path2.CloseAllFigures();

            SubmitButton.Region = new Region(path2);

        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            bool tap = true;

            string email_ = "@gmail.com";
            if (emailTextBox1.Text.Length >= email_.Length)
            {
                for (int i = 0; i < email_.Length; i++)
                {
                    if (emailTextBox1.Text[emailTextBox1.Text.Length-(i+1)] != email_[9 - i]) { tap = false; break; }
                }
            }

            if (tap) {


                string senderEmail = "figmaf098@gmail.com";
                string senderPassword = "sjce rmeu scnr yrmz";

                string recipientEmail = $"{emailTextBox1.Text}";

                MailMessage mailMessage = new MailMessage(senderEmail, recipientEmail);
                mailMessage.Subject = "Email Notification";
                mailMessage.Body = $"{randomSay}";


                SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");
                smtpClient.Port = 587;
                smtpClient.Credentials = new NetworkCredential(senderEmail, senderPassword);
                smtpClient.EnableSsl = true;

                smtpClient.Send(mailMessage);


                this.Hide();
                Form = new Form4(this, emailTextBox1.Text,randomSay, Base);
                Form.Show();
            }
        }

        private void emailTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void emailTextBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (y1)
            {
                emailTextBox1.Text = "";
                y1 = false;           
            }

        }
    }
}
