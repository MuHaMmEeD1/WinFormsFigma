﻿namespace WinForms_C__LESSON_FIGMA_TASK
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form3));
            pictureBox1 = new PictureBox();
            emailTextBox1 = new TextBox();
            label1 = new Label();
            SubmitButton = new Button();
            label3 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-2, 40);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(378, 197);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // emailTextBox1
            // 
            emailTextBox1.BorderStyle = BorderStyle.None;
            emailTextBox1.Font = new Font("Sans Serif Collection", 9.8F, FontStyle.Bold, GraphicsUnit.Point);
            emailTextBox1.ForeColor = Color.Silver;
            emailTextBox1.Location = new Point(70, 271);
            emailTextBox1.Name = "emailTextBox1";
            emailTextBox1.Size = new Size(238, 41);
            emailTextBox1.TabIndex = 4;
            emailTextBox1.Text = "e-mail";
            emailTextBox1.MouseClick += emailTextBox1_MouseClick;
            emailTextBox1.TextChanged += emailTextBox1_TextChanged;
            // 
            // label1
            // 
            label1.BackColor = SystemColors.Window;
            label1.Location = new Point(58, 261);
            label1.Name = "label1";
            label1.Size = new Size(260, 60);
            label1.TabIndex = 5;
            // 
            // SubmitButton
            // 
            SubmitButton.BackColor = Color.FromArgb(32, 60, 133);
            SubmitButton.FlatStyle = FlatStyle.Flat;
            SubmitButton.Font = new Font("Sans Serif Collection", 6.1F, FontStyle.Bold, GraphicsUnit.Point);
            SubmitButton.ForeColor = Color.FromArgb(240, 240, 240);
            SubmitButton.Location = new Point(57, 349);
            SubmitButton.Name = "SubmitButton";
            SubmitButton.Size = new Size(261, 54);
            SubmitButton.TabIndex = 7;
            SubmitButton.Text = "Send code";
            SubmitButton.UseVisualStyleBackColor = true;
            SubmitButton.Click += SubmitButton_Click;
            // 
            // label3
            // 
            label3.Font = new Font("Segoe Fluent Icons", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(83, 664);
            label3.Name = "label3";
            label3.Size = new Size(227, 17);
            label3.TabIndex = 8;
            label3.Text = "a product by Product Design LLC";
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(375, 700);
            Controls.Add(label3);
            Controls.Add(SubmitButton);
            Controls.Add(emailTextBox1);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form3";
            StartPosition = FormStartPosition.CenterScreen;
            Load += Form3_Load;
            FormClosed += FormClosed_;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private TextBox emailTextBox1;
        private Label label1;
        private Button SubmitButton;
        private Label label3;
    }
}