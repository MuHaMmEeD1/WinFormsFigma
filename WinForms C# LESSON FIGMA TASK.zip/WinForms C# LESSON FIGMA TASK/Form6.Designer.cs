﻿namespace WinForms_C__LESSON_FIGMA_TASK
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form6));
            label3 = new Label();
            EsasLabel4 = new Label();
            EsasButton1 = new Button();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // label3
            // 
            label3.BackColor = Color.FromArgb(50, 143, 76);
            label3.Font = new Font("Segoe UI Variable Display", 12F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.White;
            label3.Location = new Point(102, 323);
            label3.Name = "label3";
            label3.Size = new Size(174, 55);
            label3.TabIndex = 24;
            label3.Text = "Registeration is succesfully done!";
            label3.TextAlign = ContentAlignment.MiddleCenter;
            label3.Click += label3_Click;
            // 
            // EsasLabel4
            // 
            EsasLabel4.BackColor = Color.FromArgb(50, 143, 76);
            EsasLabel4.ForeColor = Color.White;
            EsasLabel4.Location = new Point(58, 250);
            EsasLabel4.Name = "EsasLabel4";
            EsasLabel4.Size = new Size(260, 200);
            EsasLabel4.TabIndex = 25;
            EsasLabel4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // EsasButton1
            // 
            EsasButton1.BackColor = Color.FromArgb(50, 143, 76);
            EsasButton1.FlatStyle = FlatStyle.Flat;
            EsasButton1.Font = new Font("Sans Serif Collection", 6.1F, FontStyle.Bold, GraphicsUnit.Point);
            EsasButton1.ForeColor = SystemColors.Control;
            EsasButton1.Location = new Point(56, 482);
            EsasButton1.Name = "EsasButton1";
            EsasButton1.Size = new Size(261, 54);
            EsasButton1.TabIndex = 26;
            EsasButton1.Text = "Go to sign in page";
            EsasButton1.UseVisualStyleBackColor = false;
            EsasButton1.Click += EsasButton1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.ErrorImage = (Image)resources.GetObject("pictureBox2.ErrorImage");
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(0, 0);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(375, 700);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 28;
            pictureBox2.TabStop = false;
            pictureBox2.Click += pictureBox2_Click;
            // 
            // Form6
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(375, 700);
            Controls.Add(EsasButton1);
            Controls.Add(label3);
            Controls.Add(EsasLabel4);
            Controls.Add(pictureBox2);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form6";
            StartPosition = FormStartPosition.CenterScreen;
            Load += Form6_Load;
            FormClosed += FormClosed_;
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Label label3;
        private Label EsasLabel4;
        private Button EsasButton1;
        private PictureBox pictureBox2;
    }
}