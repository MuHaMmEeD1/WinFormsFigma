﻿namespace WinForms_C__LESSON_FIGMA_TASK
{
    partial class Home
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Home));
            pictureBox1 = new PictureBox();
            SingİnButton = new Button();
            RegisterButton = new Button();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-2, 40);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(378, 197);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // SingİnButton
            // 
            SingİnButton.BackColor = Color.FromArgb(32, 60, 133);
            SingİnButton.FlatStyle = FlatStyle.Flat;
            SingİnButton.Font = new Font("Sans Serif Collection", 6.1F, FontStyle.Bold, GraphicsUnit.Point);
            SingİnButton.ForeColor = Color.FromArgb(240, 240, 240);
            SingİnButton.Location = new Point(100, 261);
            SingİnButton.Name = "SingİnButton";
            SingİnButton.Size = new Size(175, 62);
            SingİnButton.TabIndex = 1;
            SingİnButton.Text = "Sign in";
            SingİnButton.UseVisualStyleBackColor = true;
            SingİnButton.Click += SingİnButton_Click;
            // 
            // RegisterButton
            // 
            RegisterButton.BackColor = Color.FromArgb(32, 60, 133);
            RegisterButton.FlatStyle = FlatStyle.Flat;
            RegisterButton.Font = new Font("Sans Serif Collection", 6.1F, FontStyle.Bold, GraphicsUnit.Point);
            RegisterButton.ForeColor = Color.FromArgb(240, 240, 240);
            RegisterButton.Location = new Point(100, 340);
            RegisterButton.Name = "RegisterButton";
            RegisterButton.Size = new Size(175, 62);
            RegisterButton.TabIndex = 2;
            RegisterButton.Text = "Register";
            RegisterButton.UseVisualStyleBackColor = true;
            RegisterButton.Click += RegisterButton_Click;
            // 
            // label1
            // 
            label1.Font = new Font("Segoe Fluent Icons", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(83, 664);
            label1.Name = "label1";
            label1.Size = new Size(227, 17);
            label1.TabIndex = 3;
            label1.Text = "a product by Product Design LLC";
            // 
            // Home
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(240, 240, 240);
            ClientSize = new Size(375, 700);
            Controls.Add(label1);
            Controls.Add(RegisterButton);
            Controls.Add(SingİnButton);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Home";
            StartPosition = FormStartPosition.CenterScreen;
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private Button SingİnButton;
        private Button RegisterButton;
        private Label label1;
    }
}