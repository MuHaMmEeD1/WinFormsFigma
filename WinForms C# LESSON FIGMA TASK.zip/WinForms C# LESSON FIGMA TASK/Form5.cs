﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms_C__LESSON_FIGMA_TASK
{
    public partial class Form5 : Form
    {
        public Form form;

        public Form Base;
        public Form Base2;

        public Form BaseSingIn;

        bool y1 = true;
        bool y2 = true;

        public string email;

        public Form5(Form baseSingIn, Form Base, Form Base2, string email)
        {
            InitializeComponent();
            BaseSingIn = baseSingIn;
            this.Base = Base;
            this.Base2 = Base2;
            this.email = email;
        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void FormClosed_(object? sender, EventArgs e)
        {

            Base.Dispose();
            Base2.Dispose();
            BaseSingIn.Close();

        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            GraphicsPath path = new GraphicsPath();
            int radius = 5;
            Rectangle bounds = new Rectangle(0, 0, label1.Width - 2, label1.Height - 2);

            path.AddArc(bounds.Left, bounds.Top, radius, radius, 180, 90);
            path.AddArc(bounds.Right - radius, bounds.Top, radius, radius, 270, 90);
            path.AddArc(bounds.Right - radius, bounds.Bottom - radius, radius, radius, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - radius, radius, radius, 90, 90);
            path.CloseAllFigures();

            label1.Region = new Region(path);



            GraphicsPath path2 = new GraphicsPath();
            int radius2 = 5;
            Rectangle bounds2 = new Rectangle(0, 0, label2.Width - 2, label2.Height - 2);

            path2.AddArc(bounds2.Left, bounds2.Top, radius2, radius2, 180, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Top, radius2, radius2, 270, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Bottom - radius2, radius2, radius2, 0, 90);
            path2.AddArc(bounds2.Left, bounds2.Bottom - radius2, radius2, radius2, 90, 90);
            path2.CloseAllFigures();

            label2.Region = new Region(path2);


            GraphicsPath path3 = new GraphicsPath();
            int radius3 = 15;
            Rectangle bounds3 = new Rectangle(0, 0, updatePasswordButton.Width - 2, updatePasswordButton.Height - 2);

            path3.AddArc(bounds3.Left, bounds3.Top, radius3, radius3, 180, 90);
            path3.AddArc(bounds3.Right - radius3, bounds3.Top, radius3, radius3, 270, 90);
            path3.AddArc(bounds3.Right - radius3, bounds3.Bottom - radius3, radius3, radius3, 0, 90);
            path3.AddArc(bounds3.Left, bounds3.Bottom - radius3, radius3, radius3, 90, 90);
            path3.CloseAllFigures();

            updatePasswordButton.Region = new Region(path3);





        }

        private void updatePasswordButton_Click(object sender, EventArgs e)
        {

            if (newPassTextBox1.Text == confirmPassTextBox1.Text && newPassTextBox1.Text.Length >= 7)
            {

              
                List<Person> list = new List<Person>();


                list = JsonSerializer.Deserialize<List<Person>>(File.ReadAllText("../../../persons.json"));


                for (int i = 0; i < list.Count; i++)
                {
                    if (list[i].Email == email) { list[i].Password = newPassTextBox1.Text; break; } 
                }


                File.WriteAllText("../../../persons.json", JsonSerializer.Serialize(list, new JsonSerializerOptions() { WriteIndented = true }));


                this.Hide();
                form = new Form6(this, BaseSingIn, Base, Base2);
                form.Show();
            }
            else
            {

                newPassTextBox1.ForeColor = Color.Red;
                confirmPassTextBox1.ForeColor = Color.Red;

            };

        }

        private void newPassTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void newPassTextBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (y1)
            {
                newPassTextBox1.Text = "";

                y1 = false;
            }
        }

        private void confirmPassTextBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (y2)
            {
                confirmPassTextBox1.Text = "";

                y2 = false;
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
