﻿using System.Drawing.Drawing2D;

namespace WinForms_C__LESSON_FIGMA_TASK
{
    public partial class Home : Form
    {

        public Form form2;
        public Form form2_1;



        public Home()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

           
            
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            GraphicsPath path = new GraphicsPath();
            int radius = 18;
            Rectangle bounds = new Rectangle(0, 0, SingİnButton.Width - 1, SingİnButton.Height - 1);

            path.AddArc(bounds.Left, bounds.Top, radius, radius, 180, 90);
            path.AddArc(bounds.Right - radius, bounds.Top, radius, radius, 270, 90);
            path.AddArc(bounds.Right - radius, bounds.Bottom - radius, radius, radius, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - radius, radius, radius, 90, 90);
            path.CloseAllFigures();

            SingİnButton.Region = new Region(path);



            GraphicsPath path2 = new GraphicsPath();
            int radius2 = 12;
            Rectangle bounds2 = new Rectangle(0, 0, RegisterButton.Width - 1, RegisterButton.Height - 1);

            path2.AddArc(bounds2.Left, bounds2.Top, radius2, radius2, 180, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Top, radius2, radius2, 270, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Bottom - radius2, radius2, radius2, 0, 90);
            path2.AddArc(bounds2.Left, bounds2.Bottom - radius2, radius2, radius2, 90, 90);
            path2.CloseAllFigures();

            RegisterButton.Region = new Region(path2);

        }

        private void SingİnButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            form2 = new Sign_in(this);
            form2.Show();
        }

        private void RegisterButton_Click(object sender, EventArgs e)
        {

            this.Hide();
            form2_1 = new Form2_1(this);
            form2_1.Show();
        }
    }
}