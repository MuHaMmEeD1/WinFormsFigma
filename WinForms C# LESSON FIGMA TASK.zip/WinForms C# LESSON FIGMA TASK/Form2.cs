﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics.Metrics;
using System.Text.Json;

namespace WinForms_C__LESSON_FIGMA_TASK
{
    public partial class Sign_in : Form
    {

        public Form form3;
        public Form formSon;

        public Form Base;

        bool y1 = true;
        bool y2 = true;

        int say = 3;
        int say2 = 3;

        public Sign_in(Form Base)
        {
            InitializeComponent();
            this.Base = Base;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            GraphicsPath path = new GraphicsPath();
            int radius = 5;
            Rectangle bounds = new Rectangle(0, 0, label1.Width - 2, label1.Height - 2);

            path.AddArc(bounds.Left, bounds.Top, radius, radius, 180, 90);
            path.AddArc(bounds.Right - radius, bounds.Top, radius, radius, 270, 90);
            path.AddArc(bounds.Right - radius, bounds.Bottom - radius, radius, radius, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - radius, radius, radius, 90, 90);
            path.CloseAllFigures();

            label1.Region = new Region(path);



            GraphicsPath path2 = new GraphicsPath();
            int radius2 = 5;
            Rectangle bounds2 = new Rectangle(0, 0, label2.Width - 2, label2.Height - 2);

            path2.AddArc(bounds2.Left, bounds2.Top, radius2, radius2, 180, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Top, radius2, radius2, 270, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Bottom - radius2, radius2, radius2, 0, 90);
            path2.AddArc(bounds2.Left, bounds2.Bottom - radius2, radius2, radius2, 90, 90);
            path2.CloseAllFigures();

            label2.Region = new Region(path2);


            GraphicsPath path3 = new GraphicsPath();
            int radius3 = 15;
            Rectangle bounds3 = new Rectangle(0, 0, SingİnButton.Width - 2, SingİnButton.Height - 2);

            path3.AddArc(bounds3.Left, bounds3.Top, radius3, radius3, 180, 90);
            path3.AddArc(bounds3.Right - radius3, bounds3.Top, radius3, radius3, 270, 90);
            path3.AddArc(bounds3.Right - radius3, bounds3.Bottom - radius3, radius3, radius3, 0, 90);
            path3.AddArc(bounds3.Left, bounds3.Bottom - radius3, radius3, radius3, 90, 90);
            path3.CloseAllFigures();

            SingİnButton.Region = new Region(path3);





        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

            List<Person> persons = new List<Person>();

            persons = JsonSerializer.Deserialize<List<Person>>(File.ReadAllText("../../../persons.json"));

            bool yoxla = false;

            for (int i = 0; i < persons.Count; i++)
            {
                if (persons[i].Email == logInTextBox1.Text)
                {
                    yoxla = true;
                    break;
                }
            }


            if (yoxla)
            {
                this.Hide();
                form3 = new Form3(this);
                form3.Show();
            }
            else { logInTextBox1.ForeColor = Color.Red; say--; }

            if(say == 0)
            {

                Base.Show();
                this.Dispose();
            }

        }

        private void SingİnButton_Click(object sender, EventArgs e)
        {
            int index = 0;

            List<Person> persons = new List<Person>();

            persons = JsonSerializer.Deserialize<List<Person>>(File.ReadAllText("../../../persons.json"));

            bool yoxlayan = false;

            for (int i = 0; i < persons.Count; i++)
            {
                if (persons[i].Email == logInTextBox1.Text && persons[i].Password == textBox1.Text)
                {
                    index = i;
                    yoxlayan = true;
                    break;
                }
            }

            if (yoxlayan)
            {
                this.Hide();
                formSon = new Form7(this, Base, index);
                formSon.Show();
            }
            else { logInTextBox1.ForeColor = Color.Red; textBox1.ForeColor = Color.Red; say2--; }

            if(say2 == 0)
            {
                Base.Show();
                this.Dispose();
            }

        }

        private void FormClosed_(object? sender, EventArgs e)
        {

            Base.Close();

        }

        private void logInTextBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (y1)
            {
                logInTextBox1.Text = "";
                y1 = false;
            }
        }

        private void textBox1_MouseClick(object sender, MouseEventArgs e)
        {

            if (y2)
            {
                textBox1.Text = "";
                y2 = false;
            }
        
        }
    }
}
