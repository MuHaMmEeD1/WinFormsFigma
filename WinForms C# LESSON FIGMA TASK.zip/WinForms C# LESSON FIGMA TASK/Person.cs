﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WinForms_C__LESSON_FIGMA_TASK
{
    public class Person
    {

        public string Fastname { get; set; }
        public string Lastname { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string Imag { get; set; }


    }
}
