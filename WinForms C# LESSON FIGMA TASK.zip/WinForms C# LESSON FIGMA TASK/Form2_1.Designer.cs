﻿namespace WinForms_C__LESSON_FIGMA_TASK
{
    partial class Form2_1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2_1));
            pictureBox1 = new PictureBox();
            label3 = new Label();
            firsNameTextBox1 = new TextBox();
            label1 = new Label();
            LastNameTextBox1 = new TextBox();
            label2 = new Label();
            emailTextBox1 = new TextBox();
            label4 = new Label();
            NextButton = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-2, 40);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(378, 197);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // label3
            // 
            label3.Font = new Font("Segoe Fluent Icons", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(83, 664);
            label3.Name = "label3";
            label3.Size = new Size(227, 17);
            label3.TabIndex = 8;
            label3.Text = "a product by Product Design LLC";
            // 
            // firsNameTextBox1
            // 
            firsNameTextBox1.BorderStyle = BorderStyle.None;
            firsNameTextBox1.Font = new Font("Sans Serif Collection", 9.8F, FontStyle.Bold, GraphicsUnit.Point);
            firsNameTextBox1.ForeColor = Color.Silver;
            firsNameTextBox1.Location = new Point(70, 271);
            firsNameTextBox1.Name = "firsNameTextBox1";
            firsNameTextBox1.Size = new Size(238, 41);
            firsNameTextBox1.TabIndex = 9;
            firsNameTextBox1.Text = "first  name";
            firsNameTextBox1.MouseClick += firsNameTextBox1_TextChanged;
            // 
            // label1
            // 
            label1.BackColor = SystemColors.Window;
            label1.Location = new Point(58, 261);
            label1.Name = "label1";
            label1.Size = new Size(260, 60);
            label1.TabIndex = 10;
            // 
            // LastNameTextBox1
            // 
            LastNameTextBox1.BorderStyle = BorderStyle.None;
            LastNameTextBox1.Font = new Font("Sans Serif Collection", 9.8F, FontStyle.Bold, GraphicsUnit.Point);
            LastNameTextBox1.ForeColor = Color.Silver;
            LastNameTextBox1.Location = new Point(70, 346);
            LastNameTextBox1.Name = "LastNameTextBox1";
            LastNameTextBox1.Size = new Size(238, 41);
            LastNameTextBox1.TabIndex = 11;
            LastNameTextBox1.Text = "last  name";
            LastNameTextBox1.MouseClick += LastNameTextBox1_TextChanged;
            // 
            // label2
            // 
            label2.BackColor = SystemColors.Window;
            label2.Location = new Point(58, 336);
            label2.Name = "label2";
            label2.Size = new Size(260, 60);
            label2.TabIndex = 12;
            // 
            // emailTextBox1
            // 
            emailTextBox1.BorderStyle = BorderStyle.None;
            emailTextBox1.Font = new Font("Sans Serif Collection", 9.8F, FontStyle.Bold, GraphicsUnit.Point);
            emailTextBox1.ForeColor = Color.Silver;
            emailTextBox1.Location = new Point(70, 421);
            emailTextBox1.Name = "emailTextBox1";
            emailTextBox1.Size = new Size(238, 41);
            emailTextBox1.TabIndex = 13;
            emailTextBox1.Text = "e-mail";
            emailTextBox1.MouseClick += emailTextBox1_MouseClick;
            emailTextBox1.TextChanged += emailTextBox1_TextChanged;
            // 
            // label4
            // 
            label4.BackColor = SystemColors.Window;
            label4.Location = new Point(58, 411);
            label4.Name = "label4";
            label4.Size = new Size(260, 60);
            label4.TabIndex = 14;
            // 
            // NextButton
            // 
            NextButton.BackColor = Color.FromArgb(32, 60, 133);
            NextButton.FlatStyle = FlatStyle.Flat;
            NextButton.Font = new Font("Sans Serif Collection", 6.1F, FontStyle.Bold, GraphicsUnit.Point);
            NextButton.ForeColor = Color.FromArgb(240, 240, 240);
            NextButton.Location = new Point(56, 501);
            NextButton.Name = "NextButton";
            NextButton.Size = new Size(261, 54);
            NextButton.TabIndex = 15;
            NextButton.Text = "Next";
            NextButton.UseVisualStyleBackColor = true;
            NextButton.Click += NextButton_Click;
            // 
            // Form2_1
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(375, 700);
            Controls.Add(NextButton);
            Controls.Add(emailTextBox1);
            Controls.Add(label4);
            Controls.Add(LastNameTextBox1);
            Controls.Add(label2);
            Controls.Add(firsNameTextBox1);
            Controls.Add(label1);
            Controls.Add(label3);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form2_1";
            StartPosition = FormStartPosition.CenterScreen;
            FormClosed += FormClosed_;
            Load += Form2_1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label3;
        private TextBox firsNameTextBox1;
        private Label label1;
        private TextBox LastNameTextBox1;
        private Label label2;
        private TextBox emailTextBox1;
        private Label label4;
        private Button NextButton;
    }
}