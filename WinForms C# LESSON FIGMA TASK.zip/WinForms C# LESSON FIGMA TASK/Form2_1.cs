﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms_C__LESSON_FIGMA_TASK
{
    public partial class Form2_1 : Form
    {
        public Form form2_2;

        public Person person = new();

        public Form Base;

        bool y1 = true;
        bool y2 = true;
        bool y3 = true;


        public Form2_1(Form Base)
        {
            InitializeComponent();
            this.Base = Base;
        }

        private void Form2_1_Load(object sender, EventArgs e)
        {

        }

        private void FormClosed_(object? sender, EventArgs e)
        {

            Base.Close();

        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            GraphicsPath path = new GraphicsPath();
            int radius = 5;
            Rectangle bounds = new Rectangle(0, 0, label2.Width - 2, label2.Height - 2);

            path.AddArc(bounds.Left, bounds.Top, radius, radius, 180, 90);
            path.AddArc(bounds.Right - radius, bounds.Top, radius, radius, 270, 90);
            path.AddArc(bounds.Right - radius, bounds.Bottom - radius, radius, radius, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - radius, radius, radius, 90, 90);
            path.CloseAllFigures();

            label2.Region = new Region(path);



            GraphicsPath path2 = new GraphicsPath();
            int radius2 = 5;
            Rectangle bounds2 = new Rectangle(0, 0, label1.Width - 2, label1.Height - 2);

            path2.AddArc(bounds2.Left, bounds2.Top, radius2, radius2, 180, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Top, radius2, radius2, 270, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Bottom - radius2, radius2, radius2, 0, 90);
            path2.AddArc(bounds2.Left, bounds2.Bottom - radius2, radius2, radius2, 90, 90);
            path2.CloseAllFigures();

            label1.Region = new Region(path2);


            GraphicsPath path3 = new GraphicsPath();
            int radius3 = 5;
            Rectangle bounds3 = new Rectangle(0, 0, label4.Width - 2, label4.Height - 2);

            path3.AddArc(bounds3.Left, bounds3.Top, radius3, radius3, 180, 90);
            path3.AddArc(bounds3.Right - radius3, bounds3.Top, radius3, radius3, 270, 90);
            path3.AddArc(bounds3.Right - radius3, bounds3.Bottom - radius3, radius3, radius3, 0, 90);
            path3.AddArc(bounds3.Left, bounds3.Bottom - radius3, radius3, radius3, 90, 90);
            path3.CloseAllFigures();

            label4.Region = new Region(path3);


            GraphicsPath path4 = new GraphicsPath();
            int radius4 = 15;
            Rectangle bounds4 = new Rectangle(0, 0, NextButton.Width - 2, NextButton.Height - 2);

            path4.AddArc(bounds4.Left, bounds4.Top, radius4, radius4, 180, 90);
            path4.AddArc(bounds4.Right - radius4, bounds4.Top, radius4, radius4, 270, 90);
            path4.AddArc(bounds4.Right - radius4, bounds4.Bottom - radius4, radius4, radius4, 0, 90);
            path4.AddArc(bounds4.Left, bounds4.Bottom - radius4, radius4, radius4, 90, 90);
            path4.CloseAllFigures();

            NextButton.Region = new Region(path4);


        }


        private void firsNameTextBox1_TextChanged(object sender, EventArgs e)
        {
            if (y1)
            {
                firsNameTextBox1.Text = "";
                y1 = false;
            }
        }

        private void NextButton_Click(object sender, EventArgs e)
        {

            bool yoxla11 = true;

            List<Person> list = new List<Person>();


            list = JsonSerializer.Deserialize<List<Person>>(File.ReadAllText("../../../persons.json"))
                ;
            for (int i = 0; i < list.Count; i++)
            {
                if (list[i].Email == emailTextBox1.Text) { yoxla11 = false; }
            }



            if (emailTextBox1.ForeColor == Color.Green && firsNameTextBox1.Text.Length != 0 && LastNameTextBox1.Text.Length != 0 && yoxla11)
            {
                person.Fastname = firsNameTextBox1.Text;
                person.Lastname = LastNameTextBox1.Text;
                person.Email = emailTextBox1.Text;

                this.Hide();
                form2_2 = new Form2_2(this, Base, person);
                form2_2.Show();

            }
            else
            {
                if (firsNameTextBox1.Text.Length != 0) { firsNameTextBox1.ForeColor = Color.Red; }
                if (LastNameTextBox1.Text.Length != 0) { LastNameTextBox1.ForeColor = Color.Red; }

            }


        }




        private void emailTextBox1_TextChanged(object sender, EventArgs e)
        {



            if (emailTextBox1.TextLength >= 11)
            {

                bool yoxla = true;
                string gml = "@gmail.com";

                for (int i = 0; i < 10; i++)
                {

                    if (emailTextBox1.Text[emailTextBox1.TextLength - (1 + i)] == gml[9 - i]) { }
                    else { yoxla = false; break; }
                }


                if (yoxla) { emailTextBox1.ForeColor = Color.Green; }
                else { emailTextBox1.ForeColor = Color.Red; }


            }
            else { emailTextBox1.ForeColor = Color.Red; }
        }

        private void LastNameTextBox1_TextChanged(object sender, EventArgs e)
        {
            if (y2)
            {
                LastNameTextBox1.Text = "";
                y2 = false;
            }
        }

        private void emailTextBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (y3) { emailTextBox1.Text = ""; y3 = false; }
        }
    }
}
