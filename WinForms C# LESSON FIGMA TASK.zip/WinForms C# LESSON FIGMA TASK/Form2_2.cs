﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Metrics;
using System.DirectoryServices;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms_C__LESSON_FIGMA_TASK
{
    public partial class Form2_2 : Form
    {
        Form form6;


        Form Base1;
        Form Base2;

        Person person;

        bool y1 = true;
        bool y2 = true;
        public Form2_2(Form Base1, Form Base2, Person person)
        {
            InitializeComponent();
            this.Base1 = Base1;
            this.Base2 = Base2;
            this.person = person;
        }

        private void Form2_2_Load(object sender, EventArgs e)
        {

        }


        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            GraphicsPath path = new GraphicsPath();
            int radius = 5;
            Rectangle bounds = new Rectangle(0, 0, label1.Width - 2, label1.Height - 2);

            path.AddArc(bounds.Left, bounds.Top, radius, radius, 180, 90);
            path.AddArc(bounds.Right - radius, bounds.Top, radius, radius, 270, 90);
            path.AddArc(bounds.Right - radius, bounds.Bottom - radius, radius, radius, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - radius, radius, radius, 90, 90);
            path.CloseAllFigures();

            label1.Region = new Region(path);



            GraphicsPath path2 = new GraphicsPath();
            int radius2 = 5;
            Rectangle bounds2 = new Rectangle(0, 0, label2.Width - 2, label2.Height - 2);

            path2.AddArc(bounds2.Left, bounds2.Top, radius2, radius2, 180, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Top, radius2, radius2, 270, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Bottom - radius2, radius2, radius2, 0, 90);
            path2.AddArc(bounds2.Left, bounds2.Bottom - radius2, radius2, radius2, 90, 90);
            path2.CloseAllFigures();

            label2.Region = new Region(path2);


            GraphicsPath path3 = new GraphicsPath();
            int radius3 = 15;
            Rectangle bounds3 = new Rectangle(0, 0, ConfirmButton.Width - 2, ConfirmButton.Height - 2);

            path3.AddArc(bounds3.Left, bounds3.Top, radius3, radius3, 180, 90);
            path3.AddArc(bounds3.Right - radius3, bounds3.Top, radius3, radius3, 270, 90);
            path3.AddArc(bounds3.Right - radius3, bounds3.Bottom - radius3, radius3, radius3, 0, 90);
            path3.AddArc(bounds3.Left, bounds3.Bottom - radius3, radius3, radius3, 90, 90);
            path3.CloseAllFigures();

            ConfirmButton.Region = new Region(path3);





        }

        private void ConfirmButton_Click(object sender, EventArgs e)
        {

            if (PasswordTextBox1.Text == confirmPassTextBox1.Text && PasswordTextBox1.Text.Length > 7)
            {



                person.Password = PasswordTextBox1.Text;
                List<Person> list = new List<Person>();


                list = JsonSerializer.Deserialize<List<Person>>(File.ReadAllText("../../../persons.json"));

                list.Add(person);

                File.WriteAllText("../../../persons.json", JsonSerializer.Serialize(list, new JsonSerializerOptions() { WriteIndented = true }));

                this.Hide();
                form6 = new Form6(this, Base2, Base1, new Form());
                form6.Show();

            }
            else
            {
                PasswordTextBox1.ForeColor = Color.Red;
                confirmPassTextBox1.ForeColor = Color.Red;
            }

        }

        private void FormClosed_(object? sender, EventArgs e)
        {
            Base1.Close();
            Base2.Close();

        }

        private void PasswordTextBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (y1)
            {

                PasswordTextBox1.Text = "";

                y1 = false;
            }
        }

        private void confirmPassTextBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (y2)
            {

                confirmPassTextBox1.Text = "";

                y2 = false;
            }
        }
    }
}
