﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Net.Mail;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WinForms_C__LESSON_FIGMA_TASK
{
    public partial class Form4 : Form
    {
        public Form Form;

        public Form Base;



        public Form BaseSingIn;

        public string email;

        bool y1 = true;

        int randomSay = Random.Shared.Next(100000, 999999);

        int say = 3;

        public Form4(Form Base, string email ,int randomCode, Form BaseSingİn)
        {
            InitializeComponent();
            this.Base = Base;
            this.email = email;
            this.BaseSingIn = BaseSingİn;
            randomSay = randomCode;

        }
 
           

        private void Form4_Load(object sender, EventArgs e)
        {
          

        }

        private void FormClosed_(object? sender, EventArgs e)
        {

            Base.Dispose();
            BaseSingIn.Close();
           

        }
        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            GraphicsPath path = new GraphicsPath();
            int radius = 5;
            Rectangle bounds = new Rectangle(0, 0, label1.Width - 2, label1.Height - 2);

            path.AddArc(bounds.Left, bounds.Top, radius, radius, 180, 90);
            path.AddArc(bounds.Right - radius, bounds.Top, radius, radius, 270, 90);
            path.AddArc(bounds.Right - radius, bounds.Bottom - radius, radius, radius, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - radius, radius, radius, 90, 90);
            path.CloseAllFigures();

            label1.Region = new Region(path);



            GraphicsPath path2 = new GraphicsPath();
            int radius2 = 15;
            Rectangle bounds2 = new Rectangle(0, 0, SubmitButton.Width - 2, SubmitButton.Height - 2);

            path2.AddArc(bounds2.Left, bounds2.Top, radius2, radius2, 180, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Top, radius2, radius2, 270, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Bottom - radius2, radius2, radius2, 0, 90);
            path2.AddArc(bounds2.Left, bounds2.Bottom - radius2, radius2, radius2, 90, 90);
            path2.CloseAllFigures();

            SubmitButton.Region = new Region(path2);

        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {

            if(codeTextBox1.Text == randomSay.ToString())
            {
                this.Hide();
                Form = new Form5(BaseSingIn, this, Base, email);
                Form.Show();
            }
            else { codeTextBox1.ForeColor = Color.Red;  say--; }

            if(say == 0)
            {
                randomSay = Random.Shared.Next(100000, 999999);
                string senderEmail = "figmaf098@gmail.com";
                string senderPassword = "sjce rmeu scnr yrmz";

                string recipientEmail = $"{email}";

                MailMessage mailMessage = new MailMessage(senderEmail, recipientEmail);
                mailMessage.Subject = "Email Notification";
                mailMessage.Body = $"{randomSay}";


                SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");
                smtpClient.Port = 587;
                smtpClient.Credentials = new NetworkCredential(senderEmail, senderPassword);
                smtpClient.EnableSsl = true;

                smtpClient.Send(mailMessage);
            }


        }

        private void codeTextBox1_MouseClick(object sender, MouseEventArgs e)
        {
            if (y1)
            {

                codeTextBox1.Text = "";
                y1 = false;
            }
        }
    }
}
