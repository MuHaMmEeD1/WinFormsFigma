﻿namespace WinForms_C__LESSON_FIGMA_TASK
{
    partial class Form7
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            pictureBox1 = new PictureBox();
            label1 = new Label();
            textBox1 = new TextBox();
            l1 = new Label();
            button1 = new Button();
            button2 = new Button();
            textBox2 = new TextBox();
            l2 = new Label();
            label4 = new Label();
            button3 = new Button();
            textBox3 = new TextBox();
            l3 = new Label();
            label6 = new Label();
            button4 = new Button();
            textBox4 = new TextBox();
            l4 = new Label();
            label8 = new Label();
            pictureBox3 = new PictureBox();
            pictureBox2 = new PictureBox();
            label2 = new Label();
            label3 = new Label();
            openFileDialog1 = new OpenFileDialog();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-2, -57);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(378, 197);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label1
            // 
            label1.Font = new Font("Segoe Fluent Icons", 12.6F, FontStyle.Bold, GraphicsUnit.Point);
            label1.ForeColor = Color.FromArgb(32, 60, 133);
            label1.Location = new Point(20, 235);
            label1.Name = "label1";
            label1.Size = new Size(99, 20);
            label1.TabIndex = 3;
            label1.Text = "First name:";
            // 
            // textBox1
            // 
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("Segoe UI", 9.2F, FontStyle.Bold, GraphicsUnit.Point);
            textBox1.ForeColor = Color.FromArgb(32, 60, 133);
            textBox1.Location = new Point(34, 270);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(224, 21);
            textBox1.TabIndex = 4;
            textBox1.Text = "default";
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // l1
            // 
            l1.BackColor = SystemColors.ButtonHighlight;
            l1.Location = new Point(20, 264);
            l1.Name = "l1";
            l1.Size = new Size(249, 34);
            l1.TabIndex = 5;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ButtonHighlight;
            button1.FlatStyle = FlatStyle.Flat;
            button1.ForeColor = Color.FromArgb(32, 60, 133);
            button1.Location = new Point(279, 260);
            button1.Name = "button1";
            button1.Size = new Size(76, 39);
            button1.TabIndex = 6;
            button1.Text = "change";
            button1.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ButtonHighlight;
            button2.FlatStyle = FlatStyle.Flat;
            button2.ForeColor = Color.FromArgb(32, 60, 133);
            button2.Location = new Point(279, 343);
            button2.Name = "button2";
            button2.Size = new Size(76, 39);
            button2.TabIndex = 10;
            button2.Text = "change";
            button2.UseVisualStyleBackColor = false;
            // 
            // textBox2
            // 
            textBox2.BorderStyle = BorderStyle.None;
            textBox2.Font = new Font("Segoe UI", 9.2F, FontStyle.Bold, GraphicsUnit.Point);
            textBox2.ForeColor = Color.FromArgb(32, 60, 133);
            textBox2.Location = new Point(34, 353);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(224, 21);
            textBox2.TabIndex = 8;
            textBox2.Text = "default";
            // 
            // l2
            // 
            l2.BackColor = SystemColors.ButtonHighlight;
            l2.Location = new Point(20, 347);
            l2.Name = "l2";
            l2.Size = new Size(249, 34);
            l2.TabIndex = 9;
            // 
            // label4
            // 
            label4.Font = new Font("Segoe Fluent Icons", 12.6F, FontStyle.Bold, GraphicsUnit.Point);
            label4.ForeColor = Color.FromArgb(32, 60, 133);
            label4.Location = new Point(20, 318);
            label4.Name = "label4";
            label4.Size = new Size(99, 20);
            label4.TabIndex = 7;
            label4.Text = "Last name:";
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ButtonHighlight;
            button3.FlatStyle = FlatStyle.Flat;
            button3.ForeColor = Color.FromArgb(32, 60, 133);
            button3.Location = new Point(279, 424);
            button3.Name = "button3";
            button3.Size = new Size(76, 39);
            button3.TabIndex = 14;
            button3.Text = "change";
            button3.UseVisualStyleBackColor = false;
            // 
            // textBox3
            // 
            textBox3.BorderStyle = BorderStyle.None;
            textBox3.Font = new Font("Segoe UI", 9.2F, FontStyle.Bold, GraphicsUnit.Point);
            textBox3.ForeColor = Color.FromArgb(32, 60, 133);
            textBox3.Location = new Point(34, 434);
            textBox3.Name = "textBox3";
            textBox3.PasswordChar = '*';
            textBox3.Size = new Size(190, 21);
            textBox3.TabIndex = 12;
            textBox3.Text = "default";
            // 
            // l3
            // 
            l3.BackColor = SystemColors.ButtonHighlight;
            l3.Location = new Point(20, 428);
            l3.Name = "l3";
            l3.Size = new Size(249, 34);
            l3.TabIndex = 13;
            // 
            // label6
            // 
            label6.Font = new Font("Segoe Fluent Icons", 12.6F, FontStyle.Bold, GraphicsUnit.Point);
            label6.ForeColor = Color.FromArgb(32, 60, 133);
            label6.Location = new Point(20, 401);
            label6.Name = "label6";
            label6.Size = new Size(99, 20);
            label6.TabIndex = 11;
            label6.Text = "Password:";
            // 
            // button4
            // 
            button4.BackColor = SystemColors.ButtonHighlight;
            button4.FlatStyle = FlatStyle.Flat;
            button4.ForeColor = Color.FromArgb(32, 60, 133);
            button4.Location = new Point(279, 509);
            button4.Name = "button4";
            button4.Size = new Size(76, 39);
            button4.TabIndex = 18;
            button4.Text = "change";
            button4.UseVisualStyleBackColor = false;
            // 
            // textBox4
            // 
            textBox4.BorderStyle = BorderStyle.None;
            textBox4.Font = new Font("Segoe UI", 9.2F, FontStyle.Bold, GraphicsUnit.Point);
            textBox4.ForeColor = Color.FromArgb(32, 60, 133);
            textBox4.Location = new Point(34, 519);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(224, 21);
            textBox4.TabIndex = 16;
            textBox4.Text = "default@gmail.com";
            // 
            // l4
            // 
            l4.BackColor = SystemColors.ButtonHighlight;
            l4.Location = new Point(20, 513);
            l4.Name = "l4";
            l4.Size = new Size(249, 34);
            l4.TabIndex = 17;
            // 
            // label8
            // 
            label8.Font = new Font("Segoe Fluent Icons", 12.6F, FontStyle.Bold, GraphicsUnit.Point);
            label8.ForeColor = Color.FromArgb(32, 60, 133);
            label8.Location = new Point(20, 484);
            label8.Name = "label8";
            label8.Size = new Size(99, 20);
            label8.TabIndex = 15;
            label8.Text = "Mail:";
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.bagliGoz1;
            pictureBox3.Location = new Point(235, 434);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(30, 25);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 19;
            pictureBox3.TabStop = false;
            pictureBox3.Click += pictureBox3_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = SystemColors.Control;
            pictureBox2.Image = Properties.Resources.download;
            pictureBox2.Location = new Point(151, 105);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(74, 74);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 22;
            pictureBox2.TabStop = false;
            // 
            // label2
            // 
            label2.Font = new Font("Segoe Fluent Icons", 12.6F, FontStyle.Bold, GraphicsUnit.Point);
            label2.ForeColor = Color.FromArgb(32, 60, 133);
            label2.Location = new Point(168, 186);
            label2.Name = "label2";
            label2.Size = new Size(39, 25);
            label2.TabIndex = 23;
            label2.Text = "Edit";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.Font = new Font("Segoe Fluent Icons", 12.6F, FontStyle.Bold, GraphicsUnit.Point);
            label3.ForeColor = Color.FromArgb(32, 60, 133);
            label3.Location = new Point(169, 189);
            label3.Name = "label3";
            label3.Size = new Size(39, 25);
            label3.TabIndex = 24;
            label3.Text = "____";
            // 
            // openFileDialog1
            // 
            openFileDialog1.FileName = "openFileDialog1";
            // 
            // Form7
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(375, 700);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox3);
            Controls.Add(button4);
            Controls.Add(textBox4);
            Controls.Add(l4);
            Controls.Add(label8);
            Controls.Add(button3);
            Controls.Add(textBox3);
            Controls.Add(l3);
            Controls.Add(label6);
            Controls.Add(button2);
            Controls.Add(textBox2);
            Controls.Add(l2);
            Controls.Add(label4);
            Controls.Add(button1);
            Controls.Add(textBox1);
            Controls.Add(l1);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Form7";
            StartPosition = FormStartPosition.CenterScreen;
            FormClosed += FormClosed_;
            Load += Form7_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private TextBox textBox1;
        private Label l1;
        private Button button1;
        private Button button2;
        private TextBox textBox2;
        private Label l2;
        private Label label4;
        private Button button3;
        private TextBox textBox3;
        private Label l3;
        private Label label6;
        private Button button4;
        private TextBox textBox4;
        private Label l4;
        private Label label8;
        private PictureBox pictureBox3;
        private PictureBox pictureBox2;
        private Label label2;
        private Label label3;
        private OpenFileDialog openFileDialog1;
    }
}