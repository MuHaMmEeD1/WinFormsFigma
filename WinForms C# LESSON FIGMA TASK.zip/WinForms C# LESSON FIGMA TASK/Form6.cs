﻿using System;
using System.Buffers.Text;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinForms_C__LESSON_FIGMA_TASK
{
    public partial class Form6 : Form
    {
        Form Base;
        Form Base2;
        Form Base3;
        
        Form BaseSingIn;

        public Form6(Form @base, Form baseSingIn, Form Base2, Form Base3)
        {
            InitializeComponent();
            Base = @base;
            this.Base2 = Base2;
            this.Base3 = Base3;
            
            BaseSingIn = baseSingIn;
        }

        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void FormClosed_(object? sender, EventArgs e)
        {

            Base.Dispose();
            Base2.Dispose();
            Base3.Dispose();
            BaseSingIn.Dispose();

        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            GraphicsPath path = new GraphicsPath();
            int radius = 14;
            Rectangle bounds = new Rectangle(0, 0, EsasButton1.Width - 2, EsasButton1.Height - 2);

            path.AddArc(bounds.Left, bounds.Top, radius, radius, 180, 90);
            path.AddArc(bounds.Right - radius, bounds.Top, radius, radius, 270, 90);
            path.AddArc(bounds.Right - radius, bounds.Bottom - radius, radius, radius, 0, 90);
            path.AddArc(bounds.Left, bounds.Bottom - radius, radius, radius, 90, 90);
            path.CloseAllFigures();

            EsasButton1.Region = new Region(path);



            GraphicsPath path2 = new GraphicsPath();
            int radius2 = 7;
            Rectangle bounds2 = new Rectangle(0, 0, EsasLabel4.Width, EsasLabel4.Height);

            path2.AddArc(bounds2.Left, bounds2.Top, radius2, radius2, 180, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Top, radius2, radius2, 270, 90);
            path2.AddArc(bounds2.Right - radius2, bounds2.Bottom - radius2, radius2, radius2, 0, 90);
            path2.AddArc(bounds2.Left, bounds2.Bottom - radius2, radius2, radius2, 90, 90);
            path2.CloseAllFigures();

            EsasLabel4.Region = new Region(path2);



        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void EsasButton1_Click(object sender, EventArgs e)
        {
            Base.Dispose();
            Base2.Dispose();
            Base3.Dispose();
            BaseSingIn.Show();
            this.Dispose();
        }
    }
}
