﻿using static System.Windows.Forms.VisualStyles.VisualStyleElement.ToolTip;

namespace WinForms_C__LESSON_FIGMA_TASK
{
    partial class Sign_in
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Sign_in));
            pictureBox1 = new PictureBox();
            logInTextBox1 = new TextBox();
            label1 = new Label();
            textBox1 = new TextBox();
            label2 = new Label();
            SingİnButton = new Button();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(-2, 40);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(378, 197);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // logInTextBox1
            // 
            logInTextBox1.BorderStyle = BorderStyle.None;
            logInTextBox1.Font = new Font("Sans Serif Collection", 9.8F, FontStyle.Bold, GraphicsUnit.Point);
            logInTextBox1.ForeColor = Color.Silver;
            logInTextBox1.Location = new Point(70, 271);
            logInTextBox1.Name = "logInTextBox1";
            logInTextBox1.Size = new Size(238, 41);
            logInTextBox1.TabIndex = 2;
            logInTextBox1.Text = "log  in";
            logInTextBox1.MouseClick += logInTextBox1_MouseClick;
            logInTextBox1.TextChanged += textBox1_TextChanged;
            // 
            // label1
            // 
            label1.BackColor = SystemColors.Window;
            label1.Location = new Point(58, 261);
            label1.Name = "label1";
            label1.Size = new Size(260, 60);
            label1.TabIndex = 3;
            // 
            // textBox1
            // 
            textBox1.BorderStyle = BorderStyle.None;
            textBox1.Font = new Font("Sans Serif Collection", 9.8F, FontStyle.Bold, GraphicsUnit.Point);
            textBox1.ForeColor = Color.Silver;
            textBox1.Location = new Point(70, 348);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(238, 41);
            textBox1.TabIndex = 4;
            textBox1.Text = "password";
            textBox1.MouseClick += textBox1_MouseClick;
            // 
            // label2
            // 
            label2.BackColor = SystemColors.Window;
            label2.Location = new Point(58, 338);
            label2.Name = "label2";
            label2.Size = new Size(260, 60);
            label2.TabIndex = 5;
            // 
            // SingİnButton
            // 
            SingİnButton.BackColor = Color.FromArgb(32, 60, 133);
            SingİnButton.FlatStyle = FlatStyle.Flat;
            SingİnButton.Font = new Font("Sans Serif Collection", 6.1F, FontStyle.Bold, GraphicsUnit.Point);
            SingİnButton.ForeColor = Color.FromArgb(240, 240, 240);
            SingİnButton.Location = new Point(58, 426);
            SingİnButton.Name = "SingİnButton";
            SingİnButton.Size = new Size(261, 54);
            SingİnButton.TabIndex = 6;
            SingİnButton.Text = "Sign in";
            SingİnButton.UseVisualStyleBackColor = true;
            SingİnButton.Click += SingİnButton_Click;
            // 
            // label3
            // 
            label3.Font = new Font("Segoe Fluent Icons", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(83, 664);
            label3.Name = "label3";
            label3.Size = new Size(227, 17);
            label3.TabIndex = 7;
            label3.Text = "a product by Product Design LLC";
            // 
            // label4
            // 
            label4.Font = new Font("Segoe Fluent Icons", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(107, 485);
            label4.Name = "label4";
            label4.Size = new Size(227, 17);
            label4.TabIndex = 8;
            label4.Text = "Forgot password? renew it!";
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.BackColor = Color.Transparent;
            label5.FlatStyle = FlatStyle.Popup;
            label5.Font = new Font("Segoe Fluent Icons", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(107, 485);
            label5.Name = "label5";
            label5.Size = new Size(163, 32);
            label5.TabIndex = 9;
            label5.Text = "_______________________";
            label5.Click += label5_Click;
            // 
            // Sign_in
            // 
            AutoScaleDimensions = new SizeF(9F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(240, 240, 240);
            ClientSize = new Size(375, 700);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(label3);
            Controls.Add(SingİnButton);
            Controls.Add(textBox1);
            Controls.Add(label2);
            Controls.Add(logInTextBox1);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "Sign_in";
            StartPosition = FormStartPosition.CenterScreen;
            FormClosed += FormClosed_;
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private TextBox logInTextBox1;
        private Label label1;
        private TextBox textBox1;
        private Label label2;
        private Button SingİnButton;
        private Label label3;
        private Label label4;
        private Label label5;
    }
}